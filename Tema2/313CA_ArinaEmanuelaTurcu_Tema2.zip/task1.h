// Turcu Arina Emanuela 313CA

#pragma once

double task_1(int n, int** map, int* dim); // ok NU ARE CITIRI

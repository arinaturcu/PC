// Turcu Arina Emanuela 313CA

#pragma once
void search(int n, int **p, int* dim, int i, int j, int* supermass, int k);
void task_3(int n, int** map, int* dim);
